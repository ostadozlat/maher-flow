
(function () {
  function initMaherMobile() {
    var side = document.querySelector('aside.fixed, .sidebar.fixed, .mf-sidebar, aside');
    if (!side || document.querySelector('.mf-mobile-header')) return;

    var header = document.createElement('div');
    header.className = 'mf-mobile-header';
    header.innerHTML =
      '<button type="button" class="mf-mobile-menu-btn" aria-label="باز کردن منو" id="mfMenuOpen">☰</button>' +
      '<strong>ماهر فلو</strong>' +
      '<span aria-hidden="true">●</span>';

    document.body.insertBefore(header, document.body.firstChild);

    var backdrop = document.createElement('div');
    backdrop.className = 'mf-sidebar-backdrop';
    document.body.appendChild(backdrop);

    function open() {
      side.classList.add('mf-open');
      backdrop.classList.add('open');
      document.body.classList.add('mf-mobile-open');
    }
    function close() {
      side.classList.remove('mf-open');
      backdrop.classList.remove('open');
      document.body.classList.remove('mf-mobile-open');
    }

    document.getElementById('mfMenuOpen').addEventListener('click', open);
    backdrop.addEventListener('click', close);

    side.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () {
        if (window.innerWidth <= 1023) close();
      });
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 1023) close();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMaherMobile);
  } else {
    initMaherMobile();
  }
})();
